package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.Scanner;

public abstract class General {
    private String fileName;


    @FXML
    private  ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Label word;

    @FXML
    private Label examples;

    @FXML
    private Label translation;

    @FXML
    private Button showTranslationButton;

    @FXML
    private Button nextButton;

    @FXML
    private Button add;



    String currentWord;


    public void goToCreateCard(ActionEvent actionEvent) throws IOException {
        Stage stagee = (Stage) translation.getScene().getWindow();
        // do what you have to do
        stagee.close();
        Stage stage = new Stage();
        Pane layout = FXMLLoader.load(getClass().getResource(fileName));
        stage.setScene(new Scene(layout));
        stage.show();
    }

    @FXML
    void goBack(ActionEvent event) throws IOException {
        Stage stagee = new Stage();
        Pane layout = FXMLLoader.load(getClass().getResource("menu.fxml"));
        stagee.setScene(new Scene(layout));
        stagee.show();
        Stage stage = (Stage) translation.getScene().getWindow();
        stage.close();
    }


    public void update(String filename){
        currentWord = getRandomWordFrom(filename);
        int startWordSection = currentWord.indexOf("<");
        int stopWordSection = currentWord.indexOf(">");
        int startExample = currentWord.indexOf("{");
        int stopExample = currentWord.indexOf("}");
        int startTranslation = currentWord.indexOf("[");
        int stopTranslation = currentWord.indexOf("]");

        String wordContent = currentWord.substring(startWordSection + 1, stopWordSection);
        String exampleContent = currentWord.substring(startExample + 1, stopExample);
        String translationContent = currentWord.substring(startTranslation + 1, stopTranslation);

        word.setText(wordContent);
        examples.setText(exampleContent);
        examples.setWrapText(true);
        //Setting the alignment to the label
        examples.setTextAlignment(TextAlignment.JUSTIFY);
        translation.setText(translationContent);
        translation.setVisible(false);
    }

    public String getRandomWordFrom(String fileName){ // gets a random word from txt file
        this.fileName = fileName;
        ArrayList listOfWords = new ArrayList();
        try {
            //reading a file
            File myObj = new File(fileName);
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                listOfWords.add(data);// adding every word to list
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred: " + e);
            e.printStackTrace();
        }
        //getting a random word from a list
        Random random = new Random();
        String word = (listOfWords.get(random.nextInt(listOfWords.size())) + " ");
        return word;
    }

    public abstract void showAnswer();
}
