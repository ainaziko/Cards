package sample.animations;

import javafx.animation.ScaleTransition;
import javafx.animation.TranslateTransition;
import javafx.scene.Node;

public abstract class Move {
    private TranslateTransition tt;
    private ScaleTransition st;

    public TranslateTransition getTt() {
        return tt;
    }

    public ScaleTransition getSt() {
        return st;
    }

    //public abstract void move(Node node);
    public abstract void PlayAnim();
}
