package sample.animations;

import javafx.animation.TranslateTransition;
import javafx.scene.Node;
import javafx.util.Duration;

public class Shake extends Move{
    protected TranslateTransition tt = getTt();

    public Shake(){}

    public Shake(Node node) {
        this.tt = new TranslateTransition(Duration.millis(70.0D), node);

    }

    @Override
    public void PlayAnim(){
        this.tt.setFromX(0.0D);
        this.tt.setByX(10.0D);
        this.tt.setCycleCount(3);
        this.tt.setAutoReverse(true);
        this.tt.playFromStart();
    }
}


    /*@Override
    public void PlayAnim() {
        this.tt.playFromStart();
    }
    this.tt.setFromX(0.0D);
        this.tt.setByX(10.0D);
        this.tt.setCycleCount(3);
        this.tt.setAutoReverse(true);

     */