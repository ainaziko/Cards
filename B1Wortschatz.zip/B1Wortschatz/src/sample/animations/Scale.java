package sample.animations;

import javafx.animation.ScaleTransition;
import javafx.scene.Node;
import javafx.util.Duration;

public class Scale extends Move{
    private ScaleTransition st =getSt();

    public Scale(Node node){
        this.st = new ScaleTransition(Duration.seconds(0.2), node);
    }

    @Override
    public void PlayAnim() {
        st.setToX(1.5);
        st.setToY(1.5);
        st.setCycleCount(1);
        st.setAutoReverse(true);
        st.play();
    }
}
